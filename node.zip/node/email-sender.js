const nodemailer = require('nodemailer');

async function sendEmail() {
    let transporter = nodemailer.createTransport({
        service: 'gmail', // e.g., 'gmail'
        auth: {
            user: 'emaail@gmail.com',
            pass: 'password'
        }
    });

    // Set email options
    let mailOptions = {
        from: 'email@gmail.com',
        to: 'emaail@gmail.com',  // Set to your own email to test
        subject: 'Test Email from Node.js',
        text: 'Hello! This is a test email from Node.js.'
    };

    // Send the email
    try {
        let info = await transporter.sendMail(mailOptions);
        console.log('Email sent: ' + info.response);
    } catch (error) {
        console.error('Error sending email: ' + error.message);
    }
}

sendEmail();
